<?php
    $conn = mysqli_connect("localhost","root","123456","db_pengaduan");
?>
<link rel="stylesheet" href="css/bootstrap.min.css">