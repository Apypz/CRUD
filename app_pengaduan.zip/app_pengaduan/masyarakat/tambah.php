<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>tambah petugas</title>
</head>
<body>
    <h1>Form Tambah</h1>
    <form action="p_tambah.php" method="post">
        <label for="">Nik</label>
        <input type="text" name="nik" id=""><br>
        <label for="">Nama</label>
        <input type="text" name="nama" id=""><br>
        <label for="">Username</label>
        <input type="text" name="username" id=""><br>
        <label for="">Password</label>
        <input type="password" name="password" id=""><br>
        <label for="">Telepon</label>
        <input type="text" name="telp" id=""><br>
        <input type="submit" value="simpan">
    </form>
</body>
</html>