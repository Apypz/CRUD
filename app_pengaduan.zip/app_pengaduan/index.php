<?php
    include "koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
</head>
<body>
    <h1 align="center">Pengaduan</h1>
    <a href="tanggapan/index.php">tanggapan</a>
    <a href="pengaduan/index.php">pengaduan</a>
    <a href="masyarakat/index.php">masyarakat</a>
    <a href="petugas/index.php">petugas</a>
</body>
</html>